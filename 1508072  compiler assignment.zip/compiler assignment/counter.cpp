#include <iostream>
#include <string>
using namespace std;
int countOperators(string expr) {
    int count = 0;

    for (int i = 0; i < expr.length(); i++) {
        if (expr[i] == '+' || expr[i] == '-' ||
            expr[i] == '*' || expr[i] == '/') {
            count++;
        }
    }
    return count;
}
int main() {
    string expression;
    cout << "Enter an expression: ";
    getline(cin, expression);

    cout << "Number of operators: "
         << countOperators(expression) << endl;

    return 0;
}
